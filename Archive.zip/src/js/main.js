


$(window).scroll(function(){
    if($(this).scrollTop() > 200){
        $('.scroll-down svg').css({'display': 'none'});
    }
});
